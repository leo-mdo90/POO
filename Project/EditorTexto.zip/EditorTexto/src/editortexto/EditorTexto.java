package editortexto;

public class EditorTexto {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new interface_tela().setVisible(true);
            }
        });
    }
}

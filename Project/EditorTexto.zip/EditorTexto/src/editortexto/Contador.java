package editortexto;

// classe de contador, para ter noção das teclas anteriores e aonde setar as palavras na tela
public class Contador{
    
    int inicio;
    int fim;
    int tecla_anterior;
    int tecla_mod_anterior;
    
    public Contador(){
        inicio =0;
        fim=0;
    }
}